import os
import socket

file = open(r"C:\share_you\database\data.txt", "r")
data = file.readlines()
file.close()
size = data[1]
name = data[0].strip('\n')

host = socket.gethostname()
host= socket.gethostbyname(host)

s = socket.socket()
s.bind((host, 9999),)     #bind the ip and the port address to give unique address
s.listen(3)     #set the maximum queue for the clients to connect
#print ("listening...")
c, add = s.accept()     #accept the connections form the client

c.send(bytes(size, 'utf-8'))       #send the size of the file in encoded format
c.send(bytes(name, 'utf-8'))

file = open(data[0].strip('\n'), "rb")      #open the file in read binary mode
data = file.read()
c.send(data)        #send whole file

with open(r"C:\share_you\database\status.txt", "w") as f:
	f.write("1")

print ("1")
c.close()       #close the client
s.close()		#close the socket