


from PyQt5 import QtCore, QtGui, QtWidgets
from PyQt5.QtGui import QCursor
from PyQt5.QtWidgets import QFileDialog


class loading_screen(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        super().setWindowTitle("Wait")
        super().setLayout(QtWidgets.QVBoxLayout())
        self.label = QtWidgets.QLabel()
        super().layout().addWidget(self.label)

        self.movie = QtGui.QMovie(r"C:\share_you\images\load.gif")
        self.label.setMovie(self.movie)
        self.movie.start()
        self.label1 = QtWidgets.QLabel(text = "RECEIVING...")
        super().layout().addWidget(self.label1)
        super().show()

class Ui_Receive(object):
    def setupUi(self, Receive):
        Receive.setObjectName("Receive")
        Receive.resize(400, 271)
        self.autodetect = QtWidgets.QPushButton(Receive, clicked = lambda : self.autodetect_ip())
        self.autodetect.setGeometry(QtCore.QRect(140, 40, 111, 51))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.autodetect.setFont(font)
        self.autodetect.setObjectName("autodetect")
        self.label = QtWidgets.QLabel(Receive)
        self.label.setGeometry(QtCore.QRect(170, 110, 47, 13))
        font = QtGui.QFont()
        font.setPointSize(12)
        self.label.setFont(font)
        self.label.setStyleSheet("color : red;")
        self.label.setAlignment(QtCore.Qt.AlignCenter)
        self.label.setObjectName("label")
        self.ip = QtWidgets.QTextEdit(Receive)
        self.ip.setGeometry(QtCore.QRect(80, 150, 221, 31))
        self.ip.setObjectName("ip")

        self.enter = QtWidgets.QPushButton(Receive, clicked = lambda : self.start_receive())
        self.enter.setGeometry(QtCore.QRect(160, 210, 75, 23))
        self.enter.setObjectName("enter")

        self.retranslateUi(Receive)
        QtCore.QMetaObject.connectSlotsByName(Receive)

    def retranslateUi(self, Receive):
        _translate = QtCore.QCoreApplication.translate
        Receive.setWindowTitle(_translate("Receive", "Dialog"))
        self.autodetect.setText(_translate("Receive", "Detect Host"))
        self.label.setText(_translate("Receive", "OR"))
        self.ip.setHtml(_translate("Receive", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:\'MS Shell Dlg 2\'; font-size:8.25pt; font-weight:400; font-style:normal;\">\n"
"<p align=\"center\" style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\"><span style=\" font-size:12pt;\">192.168.43.00</span></p></body></html>"))
        self.enter.setText(_translate("Receive", "enter IP"))


    def autodetect_ip(self):
        import subprocess
        a = subprocess.Popen("arp -a", shell = True,  stdout = subprocess.PIPE) #running the adress resolution protocol
        s = a.stdout.read().decode()    #getting the output from the cmd terminal in form of string into s
        #text processing of the received string
        s = s[s.index('Internet') : ]
        l = s.split()
        self.ip.setText(l[5])
        font = QtGui.QFont("Helvitica", 13)
        self.ip.setFont(font)
        self.ip.setAlignment(QtCore.Qt.AlignCenter)

    def start_receive(self):
        import os
        import subprocess
        self.a = loading_screen()
        subprocess.Popen("Python " + r"C:\share_you\database\open_client.py", shell = True)
        





class Ui_Browse(QFileDialog):
    def setupUi(self, Browse):
        Browse.setObjectName("Browse")
        Browse.resize(400, 162)
        self.browse = QtWidgets.QPushButton(Browse, clicked = lambda : self.browse_file())
        self.browse.setGeometry(QtCore.QRect(310, 60, 75, 23))
        self.browse.setObjectName("browse")
        self.next = QtWidgets.QPushButton(Browse, clicked = lambda : self.open_server())
        self.next.setGeometry(QtCore.QRect(310, 100, 71, 21))
        self.next.setObjectName("next")

        self.transfer_status = QtWidgets.QLabel(Browse)
        self.transfer_status.setGeometry(QtCore.QRect(10, 20, 281, 20))
        self.transfer_status.setText("")
        self.transfer_status.setAlignment(QtCore.Qt.AlignCenter)
        font = QtGui.QFont("Helvitica", 15)
        self.transfer_status.setFont(font)

        self.progress = QtWidgets.QProgressBar(Browse)
        self.progress.setGeometry(QtCore.QRect(10, 100, 281, 23))
        self.progress.setObjectName("progress")
        self.progress.setHidden(True)

        self.file = QtWidgets.QLineEdit(Browse,  readOnly = True)
        self.file.setGeometry(QtCore.QRect(10, 60, 281, 20))
        self.file.setObjectName("file")

        self.retranslateUi(Browse)
        QtCore.QMetaObject.connectSlotsByName(Browse)

    def retranslateUi(self, Browse):
        _translate = QtCore.QCoreApplication.translate
        Browse.setWindowTitle(_translate("Browse", "Open File"))
        self.browse.setText(_translate("Browse", "Browse"))
        self.next.setText(_translate("Browse", "Next"))


    def browse_file(self):
        super().__init__()
        self.name = super().getOpenFileName(self, "Open", r"C:\\")
        self.file.setText(self.name[0])

    def open_server(self):
        import time
        import os
        import subprocess
        self.progress.setHidden(False)
        self.transfer_status.setText("CONNECTING...")
        for i in range (0, 6):
            self.progress.setValue(i * 4)
            time.sleep(0.1)
        size = os.path.getsize(self.name[0])    
        data_file = open(r"C:\share_you\database\data.txt", "w", newline = '\n')
        data_file.write(self.name[0] + '\n' + str(size))
        data_file.close()

        with open (r"C:\share_you\database\status.txt", "w") as f:
            f.write('0')
        #multithreading

        subprocess.Popen("python " + r"C:\share_you\database\open_server.py", shell = True)
        #print (a.stdout.decode())

        status = ''
        while (status != '1'):
            with open (r"C:\share_you\database\status.txt", "r") as f:
                status = f.read()
                time.sleep(0.1)

        self.transfer_status.setText("SENDING...")

        for i in range (21, 101):
            self.progress.setValue(i)
            time.sleep(0.1)

        self.transfer_status.setText("DONE")     



class Ui_Dialog1(object):
    def setupUi(self, Dialog1):
        Dialog1.setObjectName("Dialog1")
        Dialog1.resize(377, 490)
        Dialog1.setAutoFillBackground(False)
        self.send = QtWidgets.QPushButton(Dialog1, clicked = lambda : self.send_data(Dialog1))
        self.send.setCursor(QCursor(QtCore.Qt.PointingHandCursor))
        self.send.setGeometry(QtCore.QRect(140, 90, 91, 101))
        font = QtGui.QFont()
        font.setFamily("Algerian")
        font.setPointSize(20)
        self.send.setFont(font)
        self.send.setAutoFillBackground(False)
        self.send.setStyleSheet("background-color: limegreen;\n"
"color:white;\n"
"border-style:outset;\n"
"border-width:2px;\n"
"border-color:green;\n"
"border-radius:35;\n"
"border-style:solid;\n"
"")
        self.send.setFlat(False)
        self.send.setObjectName("send")
        self.receive = QtWidgets.QPushButton(Dialog1, clicked = lambda : self.receive_data(Dialog1))
        self.receive.setGeometry(QtCore.QRect(140, 270, 91, 101))
        self.receive.setCursor(QCursor(QtCore.Qt.PointingHandCursor))
        font = QtGui.QFont()
        font.setFamily("Algerian")
        font.setPointSize(14)
        self.receive.setFont(font)
        self.receive.setStyleSheet("background-color: red;\n"
"color:white;\n"
"border-style:outset;\n"
"border-width:2px;\n"
"border-color:red;\n"
"border-radius:35;")
        self.receive.setObjectName("receive")

        self.retranslateUi(Dialog1)
        QtCore.QMetaObject.connectSlotsByName(Dialog1)

    def send_data(self, Dialog1):
        Dialog1.destroy()
        self.dlg = QtWidgets.QDialog()
        self.ui = Ui_Browse()
        self.ui.setupUi(self.dlg)
        self.dlg.show()

    def receive_data(self, Dialog1):
        Dialog1.destroy()
        self.dlg_rcv = QtWidgets.QDialog()
        self.user_interface = Ui_Receive()
        self.user_interface.setupUi(self.dlg_rcv)
        self.dlg_rcv.show()

        

    def retranslateUi(self, Dialog1):
        _translate = QtCore.QCoreApplication.translate
        Dialog1.setWindowTitle(_translate("Dialog1", "Select"))
        self.send.setText(_translate("Dialog1", "SEND"))
        self.receive.setText(_translate("Dialog1", "RECEIVE"))


class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        MainWindow.setObjectName("MainWindow")
        MainWindow.resize(447, 591)
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.label = QtWidgets.QLabel(self.centralwidget)
        self.label.setGeometry(QtCore.QRect(-20, -100, 471, 701))
        font = QtGui.QFont()
        font.setFamily("AR BERKLEY")
        font.setPointSize(13)
        self.label.setFont(font)
        self.label.setText("")
        self.label.setPixmap(QtGui.QPixmap(r"C:\share_you\images\home.jpg"))
        self.label.setScaledContents(True)
        self.label.setObjectName("label")
        self.start = QtWidgets.QPushButton(self.centralwidget, clicked = lambda : self.start_share())
        self.start.setCursor(QCursor(QtCore.Qt.PointingHandCursor))
        self.start.setGeometry(QtCore.QRect(160, 430, 121, 51))
        font = QtGui.QFont()
        font.setFamily("AR DELANEY")
        font.setPointSize(16)
        self.start.setFont(font)
        self.start.setStyleSheet("background-color: green;\n"
"selection-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(255, 255, 255, 255));\n"
"selection-background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(255, 255, 255, 255));\n"
"color: black;\n"
"border-width: 2px;\n"
"border-radius: 20px\n"
"\n"
"")
        self.start.setFlat(False)
        self.start.setObjectName("start")
        MainWindow.setCentralWidget(self.centralwidget)
        self.menubar = QtWidgets.QMenuBar(MainWindow)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 447, 21))
        self.menubar.setObjectName("menubar")
        self.menuFile = QtWidgets.QMenu(self.menubar)
        self.menuFile.setObjectName("menuFile")
        MainWindow.setMenuBar(self.menubar)
        self.statusbar = QtWidgets.QStatusBar(MainWindow)
        self.statusbar.setObjectName("statusbar")
        MainWindow.setStatusBar(self.statusbar)
        self.actionExit = QtWidgets.QAction(MainWindow)
        self.actionExit.setObjectName("actionExit")
        self.menuFile.addAction(self.actionExit)
        self.menubar.addAction(self.menuFile.menuAction())

        self.retranslateUi(MainWindow)
        QtCore.QMetaObject.connectSlotsByName(MainWindow)

    def retranslateUi(self, MainWindow):
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "Share You"))
        self.start.setText(_translate("MainWindow", "START"))
        self.menuFile.setTitle(_translate("MainWindow", "File"))
        self.actionExit.setText(_translate("MainWindow", "Exit"))

    def start_share(self):
        MainWindow.destroy()
        self.Dialog1 = QtWidgets.QDialog()
        self.wind = Ui_Dialog1()
        self.wind.setupUi(self.Dialog1)
        self.Dialog1.show()
        



if __name__ == "__main__":
    import sys
    app = QtWidgets.QApplication(sys.argv)
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    MainWindow.show()
    sys.exit(app.exec_())
